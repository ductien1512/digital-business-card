# Hướng dẫn chạy Digital Business Card với thư viện local

Hai file `index.html` và `admin.html` đã được đổi các thư viện giao diện/JavaScript từ CDN sang thư mục `assets/`:

- `tailwindcss.js`
- `fontawesome.min.css` và các font Font Awesome trong `assets/fonts/`
- `inter.css` và các font Inter trong `assets/fonts/`
- `animate.min.css`
- `qrcode.min.js`
- `firebase-app-compat.js`
- `firebase-database-compat.js`
- `firebase-auth-compat.js`

Giữ nguyên cấu trúc thư mục khi deploy:

```text
index.html
admin.html
assets/
  tailwindcss.js
  fontawesome.min.css
  inter.css
  animate.min.css
  qrcode.min.js
  firebase-app-compat.js
  firebase-database-compat.js
  firebase-auth-compat.js
  fonts/
    fa-brands-400.woff2
    fa-regular-400.woff2
    fa-solid-900.woff2
    inter-300.ttf
    inter-400.ttf
    inter-500.ttf
    inter-600.ttf
    inter-700.ttf
```

## Mức độ hoạt động khi mất mạng

Giao diện, CSS, icon, animation, QR Code và mã JavaScript thư viện đã có thể chạy từ file local. Tuy nhiên các tính năng sau bắt buộc cần internet:

- Firebase Authentication và Realtime Database.
- Google Analytics 4.
- Formspree gửi form liên hệ.
- Cloudinary upload ảnh đại diện.
- Mở link Zalo/Facebook hoặc chia sẻ ra ngoài.

Nếu mất mạng, trang vẫn hiển thị giao diện và các dữ liệu HTML mặc định; phần Firebase sẽ không thể lấy dữ liệu realtime hoặc đăng nhập. QR Code vẫn tạo được từ URL hiện tại/fallback Zalo.

## Chạy thử local

Không bắt buộc phải có CDN, nhưng nên chạy bằng HTTP server để trình duyệt xử lý file ổn định:

```bash
cd /đường/dẫn/tới/thư_mục_dự_án
python3 -m http.server 5500
```

Mở `http://localhost:5500/index.html`. Khi cần Firebase/Auth, máy vẫn cần truy cập internet.
